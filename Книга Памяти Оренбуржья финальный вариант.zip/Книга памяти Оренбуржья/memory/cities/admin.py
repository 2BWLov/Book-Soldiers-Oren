from django.contrib import admin
from app.models import FallenSoldier
from .models import City
 
class CityAdmin(admin.ModelAdmin):
    list_display = ("name", "state",)
 
admin.site.register(City, CityAdmin)
