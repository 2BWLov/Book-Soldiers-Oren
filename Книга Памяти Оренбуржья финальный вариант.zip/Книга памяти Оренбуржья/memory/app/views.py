from django.http import HttpResponse

from django.shortcuts import render, redirect
from django.http import JsonResponse
from app.models import FallenSoldier
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.contrib.auth import login
from .forms import CustomUserCreationForm
import json


@csrf_exempt  # Временно отключаем CSRF для тестирования. В продакшене лучше использовать CSRF-токен
def create_soldier(request):
    if request.method == 'POST':
        soldier = FallenSoldier(
            Фамилия=request.POST.get('last_name'),
            Имя=request.POST.get('first_name'),
            Дата_рождения=request.POST.get('birth_date'),
            Отчество=request.POST.get('middle_name'),
            Место_рождения=request.POST.get('birth_place'),
            Конфликт=request.POST.get('conflict'),
            Звание=request.POST.get('rank'),
            Военная_часть=request.POST.get('military_unit'),
            Дата_смерти=request.POST.get('death_date'),
            Место_захоронения=request.POST.get('burial_place'),
            Награды=request.POST.get('awards'),
            Биография=request.POST.get('biography')
        )
        soldier.save()
        return JsonResponse({"message": "Солдат добавлен!"})
    
    return render(request, 'add_soldier.html')
def soldiers_view(request):
    conflict_filter = request.GET.get('conflict') 
    soldiers = FallenSoldier.objects.all() 

    if conflict_filter: 
        soldiers = FallenSoldier.objects.filter(Конфликт=conflict_filter) 

    context = {'soldiers': soldiers, 'current_conflict_filter': conflict_filter}  
    return render(request, 'soldier_list.html', context)

def adamovski_raion_page(request):
    return render(request, 'Adamovski__Raion.html')
def home_page(request):
    return render(request, 'SoldierBookOren.html') 
def Afgan(request):
    return render(request, 'Afgan.html') 
def Buguruslan_Raion(request):
    return render(request, 'Buguruslan__Raion.html')
def Chechnya(request):
    return render(request, 'Chechnya.html')
def Gruzino__Abhaziya(request):
    return render(request, 'Gruzino__Abhaziya.html')
def Siriya(request):
    return render(request, 'Siriya.html')
def SVO(request):
        return render(request, 'SVO.html')
def Vhod__Superuser(request):
        return render(request, 'Vhod__Superuser.html')
def Vhod__User(request):
        return render(request, 'Vhod__User.html')
def Vhod(request):
        return render(request, 'Vhod.html')
def VoV(request):
        return render(request, 'VoV.html')

def register_user(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST) # Создаем экземпляр формы, заполненный данными POST-запроса
        if form.is_valid(): # Проверяем, что форма заполнена корректно
            user = form.save() # Сохраняем нового пользователя в базу данных (возвращает объект User)
            login(request, user) # Автоматически аутентифицируем пользователя после регистрации
            return redirect('home_page') # Перенаправляем пользователя на главную страницу (или другую нужную страницу)
    else: # Если это GET-запрос (первый раз открываем страницу регистрации)
        form = CustomUserCreationForm() # Создаем пустую форму для отображения

    return render(request, 'registration/register.html', {'form': form}) 
def buguruslan_vov_soldiers_view(request):
    soldiers = FallenSoldier.objects.filter(
        military_unit__icontains='Бугуруслан',  # <---  Ищем подстроку "Бугуруслан"
        conflict='Великая Отечественная война'
    )
    context = {'soldiers': soldiers}
    return render(request, 'soldier_list.html', context)