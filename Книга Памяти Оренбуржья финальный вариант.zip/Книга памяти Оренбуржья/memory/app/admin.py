from django.contrib import admin
from .models import FallenSoldier

@admin.register(FallenSoldier)
class FallenSoldierAdmin(admin.ModelAdmin):
    list_display = ('last_name', 'first_name', 'middle_name', 'conflict', 'rank', 'military_unit' )
    fields = ('last_name', 'first_name', 'middle_name', 'birth_date', 'birth_place', 'rank', 'military_unit', 'death_date', 'burial_place', 'awards', 'biography', 'conflict')