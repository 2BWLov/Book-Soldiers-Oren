from django.db import models

class FallenSoldier(models.Model):
    last_name = models.CharField(max_length=50, verbose_name="Фамилия")  
    first_name = models.CharField(max_length=50, verbose_name="Имя") 
    middle_name = models.CharField(null=True, blank=True, max_length=50, verbose_name="Отчество")  
    birth_date = models.DateField(null=True, blank=True, verbose_name="Дата рождения") 
    birth_place = models.TextField(null=True, blank=True, verbose_name="Место рождения") 
    conflict = models.CharField(max_length=100, null=True, blank=True, verbose_name="Вооруженный конфликт") 
    rank = models.CharField(max_length=50, null=True, blank=True, verbose_name="Звание")
    military_unit = models.CharField(max_length=100, null=True, blank=True, verbose_name="Военный комиссариат") 
    death_date = models.DateField(null=True, blank=True, verbose_name="Дата смерти")
    burial_place = models.TextField(null=True, blank=True, verbose_name="Место захоронения") 
    awards = models.TextField(null=True, blank=True, verbose_name="Награды") 
    biography = models.TextField(null=True, blank=True, verbose_name="Биография") 
    def __str__(self):
        return f"{self.last_name} {self.first_name}"