"""
URL configuration for memory project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth.views import LoginView
from app.views import create_soldier, adamovski_raion_page, home_page, soldiers_view, Afgan, Buguruslan_Raion, Chechnya, Gruzino__Abhaziya, Siriya, SVO, Vhod__Superuser, Vhod__User, Vhod, VoV, register_user, buguruslan_vov_soldiers_view

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home_page, name='home'),
    path('add_soldier/', create_soldier, name='AddSoldier'),
    path('home/Adamovski__Raion/', adamovski_raion_page,),
    path('soldiers/', soldiers_view, name='soldiers' ),
    path('Buguruslan__Raion/Afgan/', Afgan, name='Afgan'),
    path('Buguruslan__Raion/', Buguruslan_Raion, name='BugRaion'),
    path('Buguruslan__Raion/Chechnya/', Chechnya, name='Chechnya' ),
    path('Buguruslan__Raion/Gruzino__Abhaziya/',Gruzino__Abhaziya, name='GruzAbhaz' ),
    path('Buguruslan__Raion/Siriya/', Siriya, name='Siriya'),
    path('Buguruslan__Raion/SVO/', SVO, name='SVO'),
    path('Vhod/Vhod__Superuser', Vhod__Superuser, name='VhodSuperuser'),
    path('Vhod__User/', Vhod__User, name='VhodUser'),
    path('Buguruslan__Raion/VoV/', buguruslan_vov_soldiers_view, name='VoV'),
    path('register/', register_user, name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('Vhod.html/', Vhod, name='Vhod'),
]

